# Crime Prediction Web App (CUNY Tech Prep Project)

## Team name: Data Cops
## Team member: Bibata Rabba Idi, Fatima Javid, JianHui (Jake) Li

### Web App Description:

This web app is made using Streamlit for users to interact with the machine learning model we created [here]().

Click [here](https://fatimajavid-crimepredictionapp-homepage-lp2yy9.streamlit.app/) to access the web app.
